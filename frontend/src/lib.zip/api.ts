/**
 * API 클라이언트 설정
 * 
 * 백엔드 API와 통신하기 위한 axios 인스턴스를 제공합니다.
 */
import axios, { AxiosInstance, AxiosRequestConfig } from 'axios';

// API 기본 URL
// 환경 변수에서 가져오거나, 기본값 사용
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

/**
 * API 응답 타입
 */
export interface ApiResponse<T> {
  data: T;
  message?: string;
  status?: string;
}

/**
 * Axios 인스턴스 생성
 */
const apiClient: AxiosInstance = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000, // 10초 타임아웃
});

/**
 * 요청 인터셉터: Clerk 토큰을 헤더에 추가
 */
apiClient.interceptors.request.use(
  async (config) => {
    // Clerk 토큰을 동적으로 가져오기 위해
    // useAuth 훅을 사용하는 컴포넌트에서 직접 헤더를 설정하거나,
    // 여기서 동적으로 가져올 수 있습니다.
    // 현재는 요청 시점에 토큰을 가져오는 것이 어려우므로,
    // 각 API 호출에서 직접 헤더를 설정하는 방식을 사용합니다.
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

/**
 * 응답 인터셉터: 에러 처리
 */
apiClient.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    // 네트워크 오류 처리
    if (!error.response) {
      console.error('네트워크 오류:', error.message);
    }
    
    // 인증 오류 처리 (401)
    if (error.response?.status === 401) {
      console.warn('인증이 필요합니다.');
      // 필요시 로그인 페이지로 리다이렉트
    }
    
    return Promise.reject(error);
  }
);

export default apiClient;
