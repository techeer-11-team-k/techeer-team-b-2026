# 모바일 디버깅 체크리스트

## ✅ 수정 완료 사항

1. **포트 불일치 수정**: WebView URL을 5173 → 3000으로 변경
2. **디버깅 로그 추가**: WebView 이벤트 로깅 추가
3. **Vite 서버 설정**: host를 '0.0.0.0'으로 설정하여 외부 접근 허용

## 🔍 검증 단계

### 1단계: 웹 앱 서버 재시작
```bash
cd frontend
# 기존 서버 종료 (Ctrl+C)
npm run dev
```

**확인 사항:**
- 서버가 `http://0.0.0.0:3000` 또는 `http://localhost:3000`에서 실행되는지 확인
- 브라우저에서 `http://localhost:3000` 접속 시 정상 작동 확인

### 2단계: 모바일 앱 실행
```bash
cd mobile
npm start
```

**확인 사항:**
- Expo 개발자 도구에서 로그 확인
- WebView 로그 확인:
  - `🔄 WebView 로딩 시작: http://localhost:3000` (또는 `http://10.0.2.2:3000`)
  - `✅ WebView 로딩 완료` 또는 `❌ WebView error`

### 3단계: 실제 기기 테스트 (선택사항)

**로컬 IP 주소 확인:**
```bash
# Windows
ipconfig | findstr IPv4

# Mac/Linux
ifconfig | grep "inet "
```

**App.tsx에서 IP 주소 수정:**
```typescript
const WEB_APP_URL = __DEV__ 
  ? Platform.OS === 'android' 
    ? 'http://10.0.2.2:3000'  // Android 에뮬레이터
    : 'http://YOUR_LOCAL_IP:3000'  // 실제 기기 (예: http://192.168.1.100:3000)
  : 'https://your-production-url.com';
```

## 🐛 문제 해결

### 여전히 흰 화면인 경우

1. **콘솔 로그 확인**
   - Expo 개발자 도구에서 WebView 로그 확인
   - `❌ WebView error` 메시지 확인

2. **네트워크 확인**
   - 웹 브라우저에서 `http://localhost:3000` 접속 가능한지 확인
   - 방화벽이 포트 3000을 차단하지 않는지 확인

3. **에뮬레이터/시뮬레이터 확인**
   - Android: `http://10.0.2.2:3000` 사용
   - iOS: `http://localhost:3000` 사용
   - 실제 기기: 컴퓨터의 로컬 IP 사용

4. **Vite 서버 재시작**
   ```bash
   cd frontend
   npm run dev -- --host 0.0.0.0 --port 3000
   ```

## 📊 예상 결과

**정상 작동 시:**
- WebView가 웹 앱을 로드
- 로딩 인디케이터가 사라지고 웹 앱 화면 표시
- 콘솔에 `✅ WebView 로딩 완료` 메시지

**오류 발생 시:**
- 에러 메시지 표시
- 콘솔에 `❌ WebView error` 및 상세 정보 표시
