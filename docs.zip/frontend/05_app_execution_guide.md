# 앱 실행 가이드

## 웹 앱 실행 방법

### 1단계: 프론트엔드 폴더로 이동
```bash
cd frontend
```

### 2단계: 개발 서버 실행
```bash
npm run dev
```

### 3단계: 브라우저에서 확인
- 자동으로 브라우저가 열립니다
- 또는 수동으로 `http://localhost:3000` 접속 (또는 Vite가 표시하는 포트)

## 모바일 앱 실행 방법 (선택사항)

### 1단계: 웹 앱 먼저 실행
```bash
cd frontend
npm run dev
```

### 2단계: 모바일 앱 폴더로 이동
```bash
cd ../mobile
```

### 3단계: 모바일 앱 의존성 설치 (처음 한 번만)
```bash
npm install
```

### 4단계: 모바일 앱 실행
```bash
npm start
```

그 다음:
- **iOS 시뮬레이터**: `i` 키 누르기
- **Android 에뮬레이터**: `a` 키 누르기  
- **웹 브라우저**: `w` 키 누르기

## 문제 해결

### 포트가 이미 사용 중인 경우
```bash
# 다른 포트로 실행
npm run dev -- --port 3001
```

### 의존성 오류가 발생하는 경우
```bash
cd frontend
rm -rf node_modules package-lock.json
npm install
```

### Clerk 키 오류가 발생하는 경우
- Clerk 키가 없어도 앱은 실행됩니다 (인증 기능만 작동하지 않음)
- 실제 Clerk 키를 사용하려면 `frontend/.env` 파일에 추가:
  ```
  VITE_CLERK_PUBLISHABLE_KEY=your_key_here
  ```

## 빠른 시작 (한 번에)

```bash
# 터미널 1: 웹 앱 실행
cd frontend
npm run dev

# 터미널 2: 모바일 앱 실행 (선택사항)
cd mobile
npm start
```
