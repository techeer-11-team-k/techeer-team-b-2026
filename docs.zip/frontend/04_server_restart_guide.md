# 서버 재시작 가이드

## 🔍 문제 확인

**증상:** 모바일 앱에서 로그인 버튼 클릭 시 "Clerk Publishable Key를 설정해주세요" 경고 표시

**원인:** Vite 서버가 환경 변수를 다시 로드하지 않음

## 🚀 해결 방법

### 방법 1: 기존 서버 종료 후 재시작 (권장)

**1단계: 기존 서버 종료**
- 서버가 실행 중인 터미널에서 `Ctrl+C` 누르기
- 또는 프로세스 종료:
  ```powershell
  # Windows PowerShell
  Stop-Process -Id 19336 -Force
  ```

**2단계: 서버 재시작**
```bash
cd frontend
npm run dev
```

**3단계: 확인**
- 브라우저에서 `http://localhost:3000` 접속
- 브라우저 콘솔(F12)에서 다음 로그 확인:
  ```
  🔑 Clerk Key 로드 상태: { hasKey: true, keyLength: 50, ... }
  ```

### 방법 2: 강제 재시작

**Windows PowerShell:**
```powershell
# 포트 3000을 사용하는 프로세스 종료
Get-NetTCPConnection -LocalPort 3000 -ErrorAction SilentlyContinue | 
  ForEach-Object { Stop-Process -Id $_.OwningProcess -Force }

# 서버 재시작
cd frontend
npm run dev
```

## ✅ 검증 단계

### 1. 브라우저에서 확인
1. `http://localhost:3000` 접속
2. 브라우저 콘솔(F12) 열기
3. 다음 명령어 실행:
   ```javascript
   console.log(import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
   ```
4. **예상 결과:** `"pk_test_YOUR_KEY_HERE"` (실제 키 값이 표시됨)

### 2. 모바일 앱에서 확인
1. 모바일 앱 재시작
2. WebView가 웹 앱을 로드할 때까지 대기
3. 로그인 버튼 클릭
4. **예상 결과:** Clerk 로그인 모달이 표시됨 (경고 메시지 없음)

### 3. WebView URL 직접 접속 테스트
1. 브라우저에서 `http://10.0.2.2:3000` 접속 (Android 에뮬레이터용)
2. 브라우저 콘솔에서 환경 변수 확인
3. 로그인 버튼 클릭 테스트

## 🐛 문제 해결

### 문제: 여전히 환경 변수가 로드되지 않음

**확인 사항:**
1. `.env` 파일이 `frontend/` 폴더에 있는가?
2. 파일명이 정확히 `.env`인가? (`.env.local`, `.env.development` 아님)
3. 환경 변수 이름이 `VITE_CLERK_PUBLISHABLE_KEY`인가? (`VITE_` 접두사 필수)
4. 서버를 완전히 종료하고 재시작했는가?

**해결:**
```bash
# 1. 서버 완전 종료
# Ctrl+C 또는 프로세스 종료

# 2. 캐시 삭제 (선택사항)
cd frontend
rm -rf node_modules/.vite

# 3. 서버 재시작
npm run dev
```

## 📝 중요 사항

**Vite 환경 변수 규칙:**
- 환경 변수는 `VITE_` 접두사로 시작해야 함
- 서버 시작 시에만 로드됨 (Hot reload로는 반영 안 됨)
- `.env` 파일은 `frontend/` 폴더에 있어야 함

**모바일 앱의 `.env`는 필요 없습니다:**
- 모바일 앱은 WebView로 웹 앱을 로드합니다
- 환경 변수는 Frontend의 Vite 서버에서만 필요합니다
