# 환경 변수 확인 및 해결

## 🔍 문제 진단

### 현재 상태
- ✅ `.env` 파일 존재: `frontend/.env`
- ✅ Clerk Key 설정됨: `VITE_CLERK_PUBLISHABLE_KEY=pk_test_...`
- ❓ Vite 서버가 환경 변수를 다시 로드하지 않았을 수 있음

### 중요 사항
**모바일 앱의 `.env`는 필요 없습니다!**
- 모바일 앱은 WebView를 사용하여 웹 앱을 로드합니다
- 환경 변수는 **Frontend의 Vite 서버**에서만 필요합니다
- WebView는 단순히 웹 페이지를 로드하므로, 웹 앱의 환경 변수만 사용됩니다

## 🚀 해결 방법

### 1단계: Frontend 서버 재시작 (필수)

**기존 서버 종료:**
- 터미널에서 `Ctrl+C`로 서버 종료

**서버 재시작:**
```bash
cd frontend
npm run dev
```

**확인:**
- 브라우저 콘솔(F12)에서 다음 로그 확인:
  ```
  🔑 Clerk Key 로드 상태: { hasKey: true, ... }
  ```

### 2단계: 모바일 앱에서 확인

**Android 에뮬레이터:**
1. 모바일 앱 재시작
2. WebView가 웹 앱을 로드할 때까지 대기
3. Chrome DevTools로 WebView 디버깅:
   - `chrome://inspect` 접속
   - "Remote Target"에서 WebView 선택
   - Console 탭에서 환경 변수 로그 확인

**또는 Expo 개발자 도구:**
- Expo 개발자 도구의 로그에서 확인

### 3단계: 환경 변수 확인

**브라우저 콘솔에서 확인:**
```javascript
// 브라우저 콘솔에서 실행
console.log(import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
```

**예상 결과:**
- 정상: `"pk_test_YOUR_KEY_HERE"` (실제 키 값이 표시됨)
- 문제: `undefined` 또는 `""`

## 🐛 문제 해결

### 문제 1: 환경 변수가 로드되지 않음

**원인:** Vite 서버가 `.env` 파일을 읽지 못함

**해결:**
1. `.env` 파일이 `frontend/` 폴더에 있는지 확인
2. 파일명이 정확히 `.env`인지 확인 (`.env.local`, `.env.development` 아님)
3. Vite 서버 재시작

### 문제 2: 모바일 앱에서만 작동하지 않음

**원인:** WebView가 다른 URL에서 로드됨

**해결:**
1. WebView URL 확인: `http://10.0.2.2:3000` (Android)
2. 해당 URL에서 브라우저로 직접 접속 테스트
3. 브라우저 콘솔에서 환경 변수 확인

### 문제 3: 로그인 버튼이 작동하지 않음

**원인:** Clerk Provider가 없음

**해결:**
1. 브라우저 콘솔에서 경고 메시지 확인:
   ```
   ⚠️ Clerk Publishable Key가 설정되지 않았습니다.
   ```
2. 환경 변수가 로드되었는지 확인
3. Vite 서버 재시작

## ✅ 검증 체크리스트

- [ ] Frontend 서버가 실행 중인가?
- [ ] `.env` 파일이 `frontend/` 폴더에 있는가?
- [ ] 브라우저 콘솔에서 환경 변수가 로드되었는가?
- [ ] 모바일 앱에서 WebView가 웹 앱을 로드하는가?
- [ ] 로그인 버튼을 클릭할 수 있는가?

## 📝 참고사항

**모바일 앱의 `.env`는 필요 없습니다:**
- 모바일 앱은 단순히 WebView로 웹 앱을 로드합니다
- 환경 변수는 웹 앱(Frontend)에서만 필요합니다
- WebView는 웹 페이지를 로드하므로, 웹 앱의 환경 변수만 사용됩니다

**환경 변수는 Vite 서버 시작 시 로드됩니다:**
- `.env` 파일을 수정한 후에는 **반드시 Vite 서버를 재시작**해야 합니다
- Hot reload로는 환경 변수 변경이 반영되지 않습니다
